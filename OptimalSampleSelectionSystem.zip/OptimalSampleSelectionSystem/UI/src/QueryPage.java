import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class QueryPage extends JFrame {
    private JLabel queryLabel, positionLabel, valueLabel, valueRangeLabel;
    private JTextField firstPosTf, secondPosTf, thirdPosTf,
            firstPosNumTf, secondPosNumTf, thirdPosNumTf,
            firstPosNumTfTo, secondPosNumTfTo, thirdPosNumTfTo,
            sumTextField;
    private JComboBox<String> queryComboBox, valueComboBox, valueRangeComboBox;
    private JFileChooser fileChooser;
    private JTextArea textArea;

    private JScrollPane scrollPane;

    private JButton previousBtn, executeBtn, saveBtn;

    private List<Component> clearList = new ArrayList();

    private void createTextField(JTextField textField, GridBagConstraints c, JPanel panel, int x, int y, Insets insets){
        c.gridx = x;
        c.gridy = y;
        c.gridwidth = 1;
        c.anchor = GridBagConstraints.EAST;
        c.insets = insets;
        textField.setBackground(Color.WHITE);
        textField.setForeground(Color.DARK_GRAY);
        textField.setFont(new Font("Arial", Font.PLAIN, 14));
        Border border = BorderFactory.createLineBorder(Color.LIGHT_GRAY, 2);
        textField.setBorder(BorderFactory.createCompoundBorder(border,
                BorderFactory.createEmptyBorder(5, 10, 5, 10)));
        panel.add(textField, c);
    }

    private void createLabel(JLabel label, GridBagConstraints c, JPanel panel, int x, int y){
        c.gridx = x;
        c.gridy = y;
        c.gridwidth = 1;
        c.anchor = GridBagConstraints.WEST;
        label.setFont(new Font("Arial", Font.BOLD, 20));
        label.setForeground(Color.WHITE);
        panel.add(label, c);
    }

    private void createBtn(JButton button, GridBagConstraints c, JPanel panel, int x, int y){
        c.fill = GridBagConstraints.CENTER;
        c.gridx = x;
        c.gridy = y;
        c.gridwidth = 1;
        c.weighty = 0;
        c.anchor = GridBagConstraints.CENTER;
        c.insets = new Insets(10, 10, 10, 10);
        panel.add(button, c);
    }

    private void buildFirQueryUI(GridBagConstraints c, JPanel panel){

        c.gridx = 1;;
        c.gridy = 3;
        c.gridwidth = 2;
        String[] chooseVal = {"Please input the corresponding numbers",
                    "Please input the numbers not to be included"};
        valueComboBox = new JComboBox<>(chooseVal);
        valueComboBox.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(valueComboBox,c);
        valueComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String selectedItem = (String) valueComboBox.getSelectedItem();
                if(selectedItem.equals("Please input the corresponding numbers")){
                    valueLabel.setText("<html>Please input the <br/>corresponding numbers:</html>");
                }
                else {
                    valueLabel.setText("<html>Please input the numbers <br/>not to be included:</html>");
                }
            }

        });
        clearList.add(valueComboBox);

        valueLabel = new JLabel("<html>Please input the <br/>corresponding numbers:</html>");
        c.insets = new Insets(10, 10, 0,0);
        createLabel(valueLabel, c, panel, 0, 4);
        clearList.add(valueLabel);

        JLabel firstPosNum = new JLabel("1st: ");
        createLabel(firstPosNum, c, panel, 0, 5);
        clearList.add(firstPosNum);

        JLabel secondPosNum = new JLabel("2nd: ");
        createLabel(secondPosNum, c, panel, 1, 5);
        clearList.add(secondPosNum);

        JLabel thirdPosNum = new JLabel("3rd: ");
        createLabel(thirdPosNum, c, panel, 2, 5);
        clearList.add(thirdPosNum);

        firstPosNumTf = new JTextField();
        c.ipadx=30;
        createTextField(firstPosNumTf, c, panel, 0, 5, new Insets(10, 60, 0, 180));
        clearList.add(firstPosNumTf);

        secondPosNumTf = new JTextField();
        c.ipadx = 30;
        createTextField(secondPosNumTf, c, panel, 1, 5, new Insets(10, 60, 0, 80));
        clearList.add(secondPosNumTf);

        thirdPosNumTf = new JTextField();
        c.ipadx = 30;
        createTextField(thirdPosNumTf, c, panel, 2, 5, new Insets(10, 60, 0, 80));
        clearList.add(thirdPosNumTf);

        c.fill = GridBagConstraints.BOTH;
        c.gridx = 0;
        c.gridy = 8;
        c.gridwidth = 3;
        c.weighty = 1;
        c.anchor = GridBagConstraints.NORTH;
        c.insets = new Insets(10, 10, 10, 10);
        textArea = new JTextArea();
        textArea.setEditable(false);
        textArea.setBackground(Color.WHITE);
        textArea.setForeground(Color.BLACK);
        textArea.setFont(new Font("Arial", Font.PLAIN, 17));
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        textArea.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        scrollPane = new JScrollPane(textArea);
        scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setPreferredSize(new Dimension(100, 50));
        panel.add(scrollPane, c);
        clearList.add(textArea);
        clearList.add(scrollPane);

        createBtn(executeBtn, c, panel, 1, 9);

        createBtn(previousBtn, c, panel, 0, 9);

        createBtn(saveBtn, c, panel, 2, 9);

    }
    public QueryPage(){
        setTitle("Optimal Sample Selection System");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        ImageIcon icon = new ImageIcon("./res/icon.png");
        setIconImage(icon.getImage());
        JPanel panel = new JPanel(new GridBagLayout()) {
            // Override the paintComponent() method to draw a gradient background
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gradient = new GradientPaint(0, 0, new Color(61, 145, 64),
                        getWidth(), getHeight(), new Color(255, 255, 255));
                g2d.setPaint(gradient);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };

        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 1;
        c.insets = new Insets(10, 10, 0, 10);
        c.gridx = 0;
        c.gridy = 0;
        queryLabel = new JLabel("Query ways: ");
        queryLabel.setFont(new Font("Arial", Font.BOLD, 20));
        queryLabel.setForeground(Color.WHITE);
        panel.add(queryLabel, c);


        c.gridx = 0;
        c.gridy = 1;
        c.insets = new Insets(10, 10, 0, 10);
        positionLabel = new JLabel("Please input three positions: ");
        positionLabel.setFont(new Font("Arial", Font.BOLD, 20));
        positionLabel.setForeground(Color.WHITE);
        panel.add(positionLabel, c);


        c.gridx = 1;;
        c.gridy = 0;
        c.gridwidth = 2;
        String[] queryOps = {"Define positions and numbers",
                "Define positions and range of numbers",
                "Define positions and fixed numbers"};
        queryComboBox = new JComboBox<>(queryOps);
        queryComboBox.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(queryComboBox,c);

        queryComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String selectedItem = (String) queryComboBox.getSelectedItem();

                desctr(clearList, panel);
                switch (selectedItem){
                    case "Define positions and numbers":
                        buildFirQueryUI(c,panel);
                        break;
                    case "Define positions and range of numbers":
                        buildSecQueryUI(c,panel);
                        break;
                    case "Define positions and fixed numbers":
                        buildThirdQueryUI(c, panel);
                        break;
                }
            }

        });
        JLabel firstPos = new JLabel("1st: ");
        createLabel(firstPos, c, panel, 0, 2);

        JLabel secondPos = new JLabel("2nd: ");
        createLabel(secondPos, c, panel, 1, 2);

        JLabel thirdPos = new JLabel("3rd: ");
        createLabel(thirdPos, c, panel, 2, 2);

        firstPosTf = new JTextField();
        createTextField(firstPosTf, c, panel, 0, 2, new Insets(10, 100, 0, 180));

        secondPosTf = new JTextField();
        createTextField(secondPosTf, c, panel, 1, 2,new Insets(10, 100, 0, 80));

        thirdPosTf = new JTextField();
        createTextField(thirdPosTf, c, panel, 2, 2,new Insets(10, 100, 0, 80));

        JLabel IncludedOrNot = new JLabel("Conditions: ");
        c.insets= new Insets(10, 10, 0, 10);
        createLabel(IncludedOrNot, c, panel,0,3);


        fileChooser = new JFileChooser();



        executeBtn = new JButton("Execute"){
            {
                // Set the button's appearance and behavior
                setContentAreaFilled(false);
                setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
                setForeground(Color.WHITE);
                setFont(new Font("Arial", Font.BOLD, 14));
                setFocusPainted(false);
            }
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                int width = getWidth();
                int height = getHeight();
                GradientPaint gradient = new GradientPaint(0, 0, new Color(135, 206, 250),
                        0, height, new Color(0, 191, 255));
                g2d.setPaint(gradient);
                g2d.fillRoundRect(0, 0, width, height, height, height);
                g2d.dispose();
                super.paintComponent(g);
            }
        };

        previousBtn = new JButton("Previous"){
            {
                // Set the button's appearance and behavior
                setContentAreaFilled(false);
                setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
                setForeground(Color.WHITE);
                setFont(new Font("Arial", Font.BOLD, 14));
                setFocusPainted(false);
            }
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                int width = getWidth();
                int height = getHeight();
                GradientPaint gradient = new GradientPaint(0, 0, new Color(75, 186, 105),
                        0, height, new Color(0, 129, 69));
                g2d.setPaint(gradient);
                g2d.fillRoundRect(0, 0, width, height, height, height);
                g2d.dispose();
                super.paintComponent(g);
            }
        };

        saveBtn = new JButton("Save"){
            {
                // Set the button's appearance and behavior
                setContentAreaFilled(false);
                setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
                setForeground(Color.WHITE);
                setFont(new Font("Arial", Font.BOLD, 14));
                setFocusPainted(false);
            }
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                int width = getWidth();
                int height = getHeight();
                GradientPaint gradient = new GradientPaint(0, 0, new Color(223,27,27),
                        0, height, new Color(150,48,48));
                g2d.setPaint(gradient);
                g2d.fillRoundRect(0, 0, width, height, height, height);
                g2d.dispose();
                super.paintComponent(g);
            }
        };

        previousBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                Page.initPage.setVisible(true);
            }
        });

        saveBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                JFrame frame = new JFrame("Save the file");
                frame.setSize(300, 200);
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
                int option = fileChooser.showSaveDialog(null);
                if (option == JFileChooser.APPROVE_OPTION) {
                    File file = fileChooser.getSelectedFile();
                    System.out.println(file.getAbsolutePath());

                    try {
                        FileOutputStream fos = new FileOutputStream(file);
                        BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
                        bw.write(textArea.getText());
                        bw.close();
                        JOptionPane.showMessageDialog(null, "Save file successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    } catch (FileNotFoundException ex) {
                        ImageIcon errorIcon = new ImageIcon("./res/error.png");
                        JOptionPane.showMessageDialog(null, "Save file fail!", "Error", JOptionPane.ERROR_MESSAGE, errorIcon);
                        //throw new RuntimeException(ex);
                    } catch (IOException ex) {
                        ImageIcon errorIcon = new ImageIcon("./res/error.png");
                        JOptionPane.showMessageDialog(null, "Save file fail!", "Error", JOptionPane.ERROR_MESSAGE, errorIcon);
                        //throw new RuntimeException(ex);
                    }


// For example, write "Hello, world!" to the file

                }

            }
        });

        executeBtn.addActionListener(new ActionListener() {
            boolean isFirstTime = true;
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!isFirstTime){
                    textArea.setText("");
                    textArea.setCaretPosition(0);
                    //scrollPane.setViewportView(textArea);
                }
                isFirstTime = false;
                int queryMode = queryComboBox.getSelectedIndex();
                System.out.println(queryMode);
                int filterMode = -1;
                List<Integer> pos = new ArrayList<>();
                List<Integer> posNum = new ArrayList<>();
                if(queryMode == 0){
                    filterMode = valueComboBox.getSelectedIndex();
                    System.out.println(filterMode);
                    pos.add(Integer.parseInt(firstPosTf.getText()));
                    pos.add(Integer.parseInt(secondPosTf.getText()));
                    pos.add(Integer.parseInt(thirdPosTf.getText()));
                    posNum.add(Integer.parseInt(firstPosNumTf.getText()));
                    posNum.add(Integer.parseInt(secondPosNumTf.getText()));
                    posNum.add(Integer.parseInt(thirdPosNumTf.getText()));
                    if(filterMode == 0) {
                        textArea.append(QueryHelperUI.getQueryResult(pos, queryMode, posNum, filterMode).toString());
                    }
                    else{
                        textArea.append(QueryHelperUI.getQueryResult(pos, queryMode, posNum, filterMode).toString());
                    }
                }
                else if(queryMode == 1){
                    filterMode = valueRangeComboBox.getSelectedIndex();
                    pos.add(Integer.parseInt(firstPosTf.getText()));
                    pos.add(Integer.parseInt(secondPosTf.getText()));
                    pos.add(Integer.parseInt(thirdPosTf.getText()));
                    posNum.add(Integer.parseInt(firstPosTf.getText()));
                    posNum.add(Integer.parseInt(secondPosNumTf.getText()));
                    posNum.add(Integer.parseInt(thirdPosNumTf.getText()));
                    posNum.add(Integer.parseInt(firstPosNumTfTo.getText()));
                    posNum.add(Integer.parseInt(secondPosNumTfTo.getText()));
                    posNum.add(Integer.parseInt(thirdPosNumTfTo.getText()));
                    if(filterMode == 0) {
                        textArea.append(QueryHelperUI.getQueryResult(pos, queryMode, posNum, filterMode).toString());
                    }
                    else{
                        textArea.append(QueryHelperUI.getQueryResult(pos, queryMode, posNum, filterMode).toString());
                    }
                }
                else{
                    filterMode = -1;
                    pos.add(Integer.parseInt(firstPosTf.getText()));
                    pos.add(Integer.parseInt(secondPosTf.getText()));
                    pos.add(Integer.parseInt(thirdPosTf.getText()));
                    posNum.add(Integer.parseInt(sumTextField.getText()));
                    textArea.append(QueryHelperUI.getQueryResult(pos, queryMode, posNum, filterMode).toString());
                }
                textArea.setCaretPosition(0);
                //scrollPane.setViewportView(textArea);
            }
        });

        buildFirQueryUI(c,panel);



        add(panel);
        setVisible(true);
    }
    private void buildSecQueryUI(GridBagConstraints c, JPanel panel){

        String[] chooseVal = {"Please input the corresponding Range numbers",
                "Please input the Range numbers not to be included"};
        valueRangeLabel = new JLabel("<html>Please input the <br/> corresponding Range numbers:</html>");
        c.insets = new Insets(10, 10, 0,0);
        createLabel(valueRangeLabel, c, panel, 0, 4);
        clearList.add(valueRangeLabel);

        c.gridx = 1;;
        c.gridy = 3;
        c.gridwidth = 2;
        valueRangeComboBox = new JComboBox<>(chooseVal);
        valueRangeComboBox.setFont(new Font("Arial", Font.PLAIN, 14));
        panel.add(valueRangeComboBox,c);
        valueRangeComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                int index = valueRangeComboBox.getSelectedIndex();
                if(index == 0){
                    valueLabel.setText("<html>Please input the <br/> corresponding Range numbers:</html>");
                }
                else {
                    valueLabel.setText("<html>Please input the Range numbers <br/> not to be included:</html>");
                }
            }

        });
        clearList.add(valueRangeComboBox);



        JLabel firstPosNum = new JLabel("1st: ");
        createLabel(firstPosNum, c, panel, 0, 5);
        clearList.add(firstPosNum);

        JLabel secondPosNum = new JLabel("2nd: ");
        createLabel(secondPosNum, c, panel, 1, 5);
        clearList.add(secondPosNum);

        JLabel thirdPosNum = new JLabel("3rd: ");
        createLabel(thirdPosNum, c, panel, 2, 5);
        clearList.add(thirdPosNum);

        firstPosNumTf = new JTextField();
        c.ipadx = 40;
        createTextField(firstPosNumTf, c, panel, 0, 5, new Insets(10, 0, 0, 200));
        clearList.add(firstPosNumTf);

        firstPosNumTfTo = new JTextField();
        c.ipadx = 40;
        createTextField(firstPosNumTfTo, c, panel, 0, 5, new Insets(10, 0, 0, 100));
        clearList.add(firstPosNumTfTo);

        secondPosNumTf = new JTextField();
        createTextField(secondPosNumTf, c, panel, 1, 5,new Insets(10, 0, 0, 100));
        clearList.add(secondPosNumTf);

        secondPosNumTfTo = new JTextField();
        c.ipadx = 40;
        createTextField(secondPosNumTfTo, c, panel, 1, 5, new Insets(10, 0, 0, 20));
        clearList.add(secondPosNumTfTo);

        thirdPosNumTf = new JTextField();
        createTextField(thirdPosNumTf, c, panel, 2, 5, new Insets(10, 0, 0, 100));
        clearList.add(thirdPosNumTf);

        thirdPosNumTfTo = new JTextField();
        c.ipadx = 40;
        createTextField(thirdPosNumTfTo, c, panel, 2, 5, new Insets(10, 0, 0, 20));
        clearList.add(thirdPosNumTfTo);

        c.fill = GridBagConstraints.BOTH;
        c.gridx = 0;
        c.gridy = 6;
        c.gridwidth = 3;
        c.weighty = 1;
        c.anchor = GridBagConstraints.NORTH;
        c.insets = new Insets(10, 10, 10, 10);
        textArea = new JTextArea();
        textArea.setEditable(false);
        textArea.setBackground(Color.WHITE);
        textArea.setForeground(Color.BLACK);
        textArea.setFont(new Font("Arial", Font.PLAIN, 17));
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        textArea.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        scrollPane = new JScrollPane(textArea);
        scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setPreferredSize(new Dimension(100, 50));
        panel.add(scrollPane, c);
        clearList.add(textArea);
        clearList.add(scrollPane);

        createBtn(executeBtn, c, panel, 1, 9);

        createBtn(previousBtn, c, panel, 0, 9);

        createBtn(saveBtn, c, panel, 2, 9);

    }

    private void buildThirdQueryUI(GridBagConstraints c, JPanel panel){
        JLabel sumLabel= new JLabel("The total Sum should be: ");
        createLabel(sumLabel, c, panel, 0, 4);
        clearList.add(sumLabel);

        sumTextField = new JTextField();
        c.gridx = 1;
        c.gridy = 4;
        clearList.add(sumTextField);
        sumTextField.setBackground(Color.WHITE);
        sumTextField.setForeground(Color.DARK_GRAY);
        sumTextField.setFont(new Font("Arial", Font.PLAIN, 14));
        Border border = BorderFactory.createLineBorder(Color.LIGHT_GRAY, 2);
        sumTextField.setBorder(BorderFactory.createCompoundBorder(border,
                BorderFactory.createEmptyBorder(5, 10, 5, 10)));
        panel.add(sumTextField, c);
//
        c.fill = GridBagConstraints.BOTH;
        c.gridx = 0;
        c.gridy = 5;
        c.gridwidth = 3;
        c.weighty = 1;
        c.anchor = GridBagConstraints.NORTH;
        c.insets = new Insets(10, 10, 10, 10);
        textArea = new JTextArea();
        textArea.setEditable(false);
        textArea.setBackground(Color.WHITE);
        textArea.setForeground(Color.BLACK);
        textArea.setFont(new Font("Arial", Font.PLAIN, 17));
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        textArea.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        scrollPane = new JScrollPane(textArea);
        scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setPreferredSize(new Dimension(100, 300));
        panel.add(scrollPane, c);
        clearList.add(textArea);
        clearList.add(scrollPane);

        createBtn(executeBtn, c, panel, 1, 6);

        createBtn(previousBtn, c, panel, 0, 6);

        createBtn(saveBtn, c, panel, 2, 6);
    }
    private void desctr(List<Component> clearList, JPanel panel){
        for(Component com: clearList){
            panel.remove(com);
        }
        //panel.removeAll();
        clearList.clear();
        panel.revalidate();
        panel.repaint();
    }
}
