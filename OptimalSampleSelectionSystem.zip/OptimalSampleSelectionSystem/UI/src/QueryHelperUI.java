import java.io.*;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class QueryHelperUI {
    public static StringBuilder getQueryResult(List<Integer> pos, int queryMode,List<Integer> posNum, int filterMode) {
        StringBuilder strb = new StringBuilder();
        File dbDir = new File("./db");
        File[] files = dbDir.listFiles();
        try {
            if (files != null) {
                if (queryMode == 0)
                {
                    for (File f : files)
                    {
                        if(f.getAbsolutePath().contains(".db")){
                            continue;
                        }
                        BufferedReader reader = new BufferedReader(new FileReader(f.getAbsolutePath()));
                        String line = reader.readLine();
                        String listStr = line.substring(17, line.length()-1);
                        System.out.println(listStr);
                        List<Integer> list = Arrays.stream(listStr.split(","))
                                .map(String::trim)
                                .map(Integer::parseInt)
                                .collect(Collectors.toList());

                        boolean flag = true;
                        for (int i = 0; i < 3; i++) {
                            if (filterMode == 0) {
                                if (!Objects.equals(list.get(pos.get(i)), posNum.get(i))) {
                                    flag = false;
                                    break;
                                }
                            } else {
                                if (Objects.equals(list.get(pos.get(i)), posNum.get(i))) {
                                    flag = false;
                                    break;
                                }
                            }
                        }
                        if (flag) {
                            while (line != null) {
                                strb.append(line + "\n");
                                line = reader.readLine();
                            }
                            strb.append("\n\n");
                            reader.close();
                        }

                    }
                    if(strb.length() == 0)
                    {
                        strb.append("There is no file fulfill the condition!");
                    }
                }
                else if (queryMode == 1) {
                    for (File f : files)
                    {
                        if(f.getAbsolutePath().contains(".db")){
                            continue;
                        }
                        BufferedReader reader = new BufferedReader(new FileReader(f.getAbsolutePath()));
                        String line = reader.readLine();
                        String listStr = line.substring(17, line.length()-1);
                        System.out.println(listStr);
                        List<Integer> list = Arrays.stream(listStr.split(","))
                                .map(String::trim)
                                .map(Integer::parseInt)
                                .collect(Collectors.toList());

                        boolean flag = true;
                        for (int i = 0; i < 3; i++) {
                            if (filterMode == 0) {
                                int lhs = posNum.get(i), rhs = posNum.get(i + 3);
                                int num = list.get(pos.get(i));
                                if(num < lhs || num > rhs){
                                    flag = false;
                                }

                            } else {
                                int lhs = posNum.get(i), rhs = posNum.get(i + 3);
                                int num = list.get(pos.get(i));
                                if(num >= lhs && num <= rhs){
                                    flag = false;
                                }
                            }
                        }
                        if (flag) {
                            while (line != null) {
                                strb.append(line + "\n");
                                line = reader.readLine();
                            }
                            strb.append("\n\n");
                            reader.close();
                        }

                    }
                    if(strb.length() == 0)
                    {
                        strb.append("There is no file fulfill the condition!");
                    }
                }
                else {
                    for (File f : files) {
                        if(f.getAbsolutePath().contains(".db")){
                            continue;
                        }
                        BufferedReader reader = new BufferedReader(new FileReader(f.getAbsolutePath()));
                        String line = reader.readLine();
                        String listStr = line.substring(17, line.length()-1);
                        System.out.println(listStr);
                        List<Integer> list = Arrays.stream(listStr.split(","))
                                .map(String::trim)
                                .map(Integer::parseInt)
                                .collect(Collectors.toList());

                        boolean flag = true;
                        int sum = 0;
                        for (int i = 0; i < 3; i++) {
                            sum += list.get(pos.get(i));
                        }
                        if(sum != posNum.get(0)){
                            flag = false;
                        }
                        if (flag) {
                            while (line != null) {
                                strb.append(line + "\n");
                                line = reader.readLine();
                            }
                            strb.append("\n\n");
                            reader.close();
                        }
                    }
                    if(strb.length() == 0)
                    {
                        strb.append("There is no file fulfill the condition!");
                    }
                }
            } else {
                strb.append("There is not data in the database!");
            }
            return strb;
        }catch (IOException ex){
            return strb;
        }
    }
}
